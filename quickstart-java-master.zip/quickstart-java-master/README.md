# Firebase Quickstarts for Java

A collection of quickstart samples demonstrating the Firebase APIs using the Admin Java SDK. For more information, see https://firebase.google.com.

## How to make contributions?
Please read and follow the steps in the [CONTRIBUTING.md](CONTRIBUTING.md)

## License
See [LICENSE](LICENSE)
